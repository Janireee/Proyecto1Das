package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Preferencias extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preferencias);

        getSupportFragmentManager().beginTransaction().replace(R.id.contenedorAjustes, new Ajustes()).commit();
    }
}