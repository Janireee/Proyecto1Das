package com.example.listview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity implements DialogoLoginFragment.ListenerDialogoLoginFragment {

    EditText username, password;
    Button btnLogin, btnNoCuenta;
    DBHelper DB;
    private GestorIdiomas gestorIdiomas;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Crear instancia del GestorIdiomas
        GestorIdiomas gestorIdiomas = new GestorIdiomas(this);

        // Obtener el idioma actual y aplicarlo
        String idiomaActual = gestorIdiomas.getIdiomaActual();
        gestorIdiomas.cambiarIdioma(idiomaActual);

        setContentView(R.layout.login);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        username = (EditText) findViewById(R.id.username1);
        password = (EditText) findViewById(R.id.password1);
        btnLogin = (Button) findViewById(R.id.btnsingin1);
        btnNoCuenta = (Button) findViewById(R.id.btnNoCuenta);
        DB = new DBHelper(this);
        //gestorIdiomas = new GestorIdiomas(this);

        btnNoCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Registro.class);
                startActivity(intent);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if (user.equals("") || pass.equals(""))
                    Toast.makeText(Login.this, R.string.Rellene_todos_los_campos, Toast.LENGTH_SHORT).show();
                else{
                    Boolean checkuserpass = DB.checkusernamepassword(user, pass);
                    if (checkuserpass == true){
                        Toast.makeText(Login.this, R.string.Inicio_de_sesion_correcto, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), Juegos.class);
                        startActivity(intent);



                    } else {
                        DialogFragment dialog = new DialogoLoginFragment();
                        dialog.show(getSupportFragmentManager(), "dialogo_crear");
                    }
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_ajustes:
                llamarAjustes();
                break;
            default:
                break;
        }
        return true;
    }

    public void llamarAjustes() {
        Intent intent = new Intent(this, Preferencias.class);
        startActivity(intent);
        finish();
    }


    @Override
    public void alPulsarCrear() {
        Intent intent = new Intent(this, Registro.class);
        startActivity(intent);
    }

    @Override
    public void alPulsarCancelar() {
        Intent intent = new Intent(this, Portada.class);
        startActivity(intent);
    }

}