package com.example.listview;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.preference.PreferenceFragmentCompat;

public class Ajustes extends PreferenceFragmentCompat implements SharedPreferences.OnSharedPreferenceChangeListener {
    GestorIdiomas gestorIdiomas;

    public Ajustes() { }

    @Override
    public void onCreatePreferences(@Nullable Bundle savedInstanceState, @Nullable String key) {
        setPreferencesFromResource(R.xml.pref_config, key);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        String idiomaSeleccionado = sharedPreferences.getString(key, "es");
        gestorIdiomas = new GestorIdiomas(getActivity());
        switch (key) {
            case "idioma":
                gestorIdiomas.cambiarIdioma(idiomaSeleccionado);
                getActivity().finish();
                Intent i = new Intent(getContext(), Login.class);
                startActivity(i);
                break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }
}