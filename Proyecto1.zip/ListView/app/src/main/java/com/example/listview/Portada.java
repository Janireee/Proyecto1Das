package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Portada extends AppCompatActivity {
    Button botonEmpezar;
    private GestorIdiomas gestorIdiomas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Crear instancia del GestorIdiomas
        GestorIdiomas gestorIdiomas = new GestorIdiomas(this);

        // Obtener el idioma actual y aplicarlo
        String idiomaActual = gestorIdiomas.getIdiomaActual();
        gestorIdiomas.cambiarIdioma(idiomaActual);

        setContentView(R.layout.portada);
        botonEmpezar = (Button) findViewById(R.id.btnEmpezar);

        botonEmpezar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
            }
        });
    }
}