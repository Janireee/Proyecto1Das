package com.example.listview;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;


public class DialogoLoginFragment extends DialogFragment {
    private ListenerDialogoLoginFragment listenerLogin;

    public interface ListenerDialogoLoginFragment {
        void alPulsarCrear();
        void alPulsarCancelar();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listenerLogin = (ListenerDialogoLoginFragment) context;
        } catch (ClassCastException e) {
            throw new ClassCastException("La clase" + context.toString() + "fallo de interfaz ListenerDialogoLoginFragment");
        }
    }

    public Dialog onCreateDialog (Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(R.string.NoExiste)
                .setPositiveButton(R.string.CrearCuenta, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        listenerLogin.alPulsarCrear();
                    }
                })
                .setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        listenerLogin.alPulsarCancelar();
                    }
                });
        return builder.create();
    }
}