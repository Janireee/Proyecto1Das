package com.example.listview;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Juegos extends AppCompatActivity {
    private ListView lvItems;
    private Adaptador adaptador;
    private ImageButton Cerrar;
    Button btnJugar, btnJugarM, btnSalir;
    private String buscaminas, monopoly, parchis, tres, uno;
    private String defBuscaminas, defMonopoly, defParchis, defTres, defUno;

    private GestorIdiomas gestorIdiomas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Crear instancia del GestorIdiomas
        GestorIdiomas gestorIdiomas = new GestorIdiomas(this);

        // Obtener el idioma actual y aplicarlo
        String idiomaActual = gestorIdiomas.getIdiomaActual();
        gestorIdiomas.cambiarIdioma(idiomaActual);
        setContentView(R.layout.juegos);

        buscaminas = getResources().getString(R.string.Buscaminas);
        monopoly = getResources().getString(R.string.Monopoly);
        parchis = getResources().getString(R.string.Parchis);
        tres = getResources().getString(R.string.Tres);
        uno = getResources().getString(R.string.Uno);

        defBuscaminas = getResources().getString(R.string.defBuscaminas);
        defMonopoly = getResources().getString(R.string.defMonopoly);
        defParchis = getResources().getString(R.string.defParchis);
        defTres = getResources().getString(R.string.defTres);
        defUno = getResources().getString(R.string.defUno);


        lvItems = (ListView) findViewById(R.id.lvItems);
        adaptador = new Adaptador(this, GetArrayItems());
        lvItems.setAdapter(adaptador);
        btnJugar = (Button) findViewById(R.id.btnJugar);


        btnJugar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Fichero.class);
                startActivity(intent);
            }
        });
    }

    private ArrayList<Entidad> GetArrayItems(){
        ArrayList<Entidad> listItems = new ArrayList<>();
        listItems.add(new Entidad(R.drawable.buscaminas, buscaminas, defBuscaminas));
        listItems.add(new Entidad(R.drawable.monopoly, monopoly, defMonopoly));
        listItems.add(new Entidad(R.drawable.parchis, parchis, defParchis));
        listItems.add(new Entidad(R.drawable.tres, tres, defTres));
        listItems.add(new Entidad(R.drawable.uno, uno, defUno));

        return listItems;
    }

}