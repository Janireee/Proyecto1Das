package com.example.listview;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;

import java.util.Locale;

public class GestorIdiomas {

    private static final String PREFERENCIAS_IDIOMA = "prefs_idioma";
    private static final String KEY_IDIOMA = "idioma";
    private Context contexto;

    public GestorIdiomas(Context contexto) {
        this.contexto = contexto;
    }

    public void cambiarIdioma(String idioma) {
        Locale locale = new Locale(idioma);
        Locale.setDefault(locale);
        Resources resources = contexto.getResources();
        Configuration config = new Configuration(resources.getConfiguration());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            config.setLocale(locale);
        } else {
            config.locale = locale;
        }
        resources.updateConfiguration(config, resources.getDisplayMetrics());

        SharedPreferences preferencias = contexto.getSharedPreferences(PREFERENCIAS_IDIOMA, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferencias.edit();
        editor.putString(KEY_IDIOMA, idioma);
        editor.apply();
    }

    public String getIdiomaActual() {
        SharedPreferences preferencias = contexto.getSharedPreferences(PREFERENCIAS_IDIOMA, Context.MODE_PRIVATE);
        return preferencias.getString(KEY_IDIOMA, Locale.getDefault().getLanguage());
    }
}
